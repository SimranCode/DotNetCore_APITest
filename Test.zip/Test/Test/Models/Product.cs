﻿using System.ComponentModel.DataAnnotations;

namespace Test.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required(ErrorMessage ="Name is mandatory")]
        public string Name { get; set; }

        [Required(ErrorMessage = "IamgeUrl is mandatory")]
        public string ImageUrl { get; set; }
        public string Description { get; set; }
    }
}
