﻿using System.Collections.Generic;
using Test.Models;

namespace Test.Repo
{
    public interface IRepository
    {
        List<Product> GetProducts();
        void AddProducts(Product product);
    }
}
