﻿using System.Collections.Generic;
using System.Linq;
using Test.Data;
using Test.Models;
using Test.Repo;

namespace Test.Repo
{
    public class Repository : IRepository
    {
        private readonly APIDbContext _dbContext;
        public Repository(APIDbContext dbContext)
        {
            _dbContext= dbContext;
        }
        public List<Product> GetProducts()
        {
            return _dbContext.Products.ToList();
        }
       

        public void AddProducts(Product product)
        {
            if (product != null)
                _dbContext.Products.Add(product);
            _dbContext.SaveChanges();
        }
    }
}
