﻿using Microsoft.EntityFrameworkCore;
using Test.Models;

namespace Test.Data
{
    public class APIDbContext : DbContext
    {
        public DbSet<Product> Products { get; set; }

        public APIDbContext(DbContextOptions<APIDbContext> options) : base(options)
        {

        }


    }
}
