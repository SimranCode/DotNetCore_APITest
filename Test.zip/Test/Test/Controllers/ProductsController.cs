﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Test.Data;
using Test.Models;
using Test.Repo;

namespace Test.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IRepository _repository;
        public ProductsController(IRepository repository)
        {
            this._repository = repository;
        }

        [HttpGet]
        public IActionResult Get()
        {
            return Ok(_repository.GetProducts());
        }

        [HttpPost]
        public IActionResult Post([FromBody]Product product)        
        { 
            _repository.AddProducts(product);
            return StatusCode(StatusCodes.Status201Created);
        }
    }
}
